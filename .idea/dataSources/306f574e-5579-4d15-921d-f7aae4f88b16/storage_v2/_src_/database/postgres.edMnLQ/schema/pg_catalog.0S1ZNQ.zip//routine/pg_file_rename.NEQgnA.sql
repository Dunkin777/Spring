create function pg_file_rename(text, text) returns boolean
    strict
    language sql
as
$$
SELECT pg_catalog.pg_file_rename($1, $2, NULL::pg_catalog.text);
$$;

alter function pg_file_rename(text, text) owner to postgres;

